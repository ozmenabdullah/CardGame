﻿using System;
using CardGameLib;
using System.Collections.Generic;

namespace CardGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Game cardGame = new Game();
            Game playerHands = new Game();
            Deck deck = new Deck();
            Cards card = new Cards();

            //Set players, number of decks, number of cards per player and certain rank or/and suit to include in game
            cardGame.numberOfPlayers = 1;
            cardGame.numberOfDecks = 1;
            cardGame.cardsPerPlayer = 1;
            cardGame.rankToUse = new List<int>() { 1, 2, 3 };
            cardGame.suitToUse = new List<string>() { "Diamonds", "Clubs" };

            /*********************************************************************
            * Example: Initiate game
            * ******************************************************************/
            Console.WriteLine("Showing loaded decks");
            cardGame.LoadDecks();
            cardGame.DisplayDeck();

            /*********************************************************************
            * Example: Shuffle decks
            * ******************************************************************/
            Console.WriteLine("\nShowing shuffled decks");
            cardGame.gameDeck = deck.Shuffle(cardGame);
            cardGame.DisplayDeck();

            /*********************************************************************
             * Example: Deal cards
             * ******************************************************************/
            Console.WriteLine("\nShowing player hands");
            playerHands.gameDeck = deck.Deal(cardGame);
            playerHands.DisplayHands();

            /*********************************************************************
            * Example: Sort player hands
            * ******************************************************************/
            Console.WriteLine("\nSorting player hands");
            playerHands.gameDeck = card.SortCards(playerHands.gameDeck);
            playerHands.DisplayHands();

            Console.WriteLine("\nCards left in deck");
            cardGame.DisplayDeck();

            Console.ReadKey();
        }
    }
}
