﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CardGameLib
{
    public class Deck
    {
        private static Random rand = new Random();

        public Deck()
        {

        }

		//Uses function Draw to deal defined number of cards and players in game from provided deck.
        public List<Cards> Deal(Game game)
        {
            int cardCount = 1;
            var collection = new List<Cards>();

            while (game.cardsPerPlayer > 0)
            {
                for (int i = 1; i < game.numberOfPlayers + 1; i++)
                {
                    var card = Draw(game);
                    if (card.Count > 0)
                    {
                        collection.Add(new Cards
                        {
                            player = i,
                            suit = card[0].suit,
                            rank = card[0].rank,
                        });
                    }
                }

                cardCount++;
                game.cardsPerPlayer--;
            }

            return collection;
        }
		
		//Function to draw a card from deck.
        public List<Cards> Draw(Game game)
        {
            var selected = game.gameDeck.Select(_ => new Cards { rank = _.rank, suit = _.suit }).ToList();
            game.gameDeck.RemoveAt(0);
            return selected;
        }
		
		//Function to generate a deck of cards.
        public List<Cards> GenerateDeck(int numberOfDecks, List<int> rankToUse, List<string> suitToUse)
        {
            int cardCount = 52 * numberOfDecks;
            int count = 1;
            string suit = "Clubs";
            var collection = new List<Cards>();
            bool addCard = false;

            for (int i = 0; i < numberOfDecks + 1; i++)
            {
                while (cardCount > 0)
                {
                    if (count == 14)
                    {
                        count = 1;

                        switch (suit)
                        {
                            case "Clubs":
                                suit = "Diamonds";
                                break;
                            case "Diamonds":
                                suit = "Hearts";
                                break;
                            case "Hearts":
                                suit = "Spades";
                                break;
                            case "Spades":
                                suit = "Clubs";
                                break;
                        }
                    }

                    if ((rankToUse.Count > 0) && (suitToUse.Count > 0))
                    {
                        if ((rankToUse.IndexOf(count) > -1) && (suitToUse.IndexOf(suit) > -1))
                        {
                            addCard = true;
                        }
                    }
                    else if ((rankToUse.Count > 0) && (rankToUse.IndexOf(count) > -1))
                    {
                        addCard = true;
                    }
                    else if ((suitToUse.Count > 0) && (suitToUse.IndexOf(suit) > -1))
                    {
                        addCard = true;
                    }
                    else if ((rankToUse.Count == 0) && (suitToUse.Count == 0))
                    {
                        addCard = true;
                    }

                    if (addCard)
                    {
                        collection.Add(new Cards
                        {
                            suit = suit,
                            rank = count,
                        });
                    }

                    count++;
                    cardCount--;
                    addCard = false;
                }
            }

            return collection;
        }
        public List<Cards> Shuffle(Game game)
        {
            return game.gameDeck.OrderBy(_ => rand.Next()).ToList();
        }
    }
}
