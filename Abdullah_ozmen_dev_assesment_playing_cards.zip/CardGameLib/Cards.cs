﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CardGameLib
{
    public class Cards
    {
        public int rank { get; set; }
        public string suit { get; set; }
        public int player { get; set; }

        public Cards()
        {
            player = 0;
        }

        //Function to sort cards according to rank and suit.
        public List<Cards> SortCards(List<Cards> cards)
        {
            if (player > 0)
            {
                return cards.Where(c => c.player == player).OrderBy(c => c.rank).ThenBy(c => c.suit).ToList();
            }
            else
            {
                return cards.OrderBy(c => c.rank).ThenBy(c => c.suit).ToList();
            }
        }
    }
}
