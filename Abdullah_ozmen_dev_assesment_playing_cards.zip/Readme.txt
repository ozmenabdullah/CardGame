CardGameLib: Source code of the card game library
NuGet: NuGet package of CardGameLib. .Net Standard 2.1.
CardGame: Example program to test the Nuget package. .Net Core 3.1
