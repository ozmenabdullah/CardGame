﻿using System;
using System.Collections.Generic;

namespace CardGameLib
{
    public class Game
    {
        Deck deck = new Deck();

        private static Random rand = new Random();
        public int numberOfPlayers { get; set; }
        public int numberOfDecks { get; set; }
        public int cardsPerPlayer { get; set; }
        public List<Cards> gameDeck { get; set; }
        public List<int> rankToUse { get; set; }
        public List<string> suitToUse { get; set; }

        public Game()
        {
            rankToUse = new List<int>();
            suitToUse = new List<string>();
        }

        //Function to generate card deck.
        public void LoadDecks()
        {
            gameDeck = deck.GenerateDeck(numberOfDecks, rankToUse, suitToUse);
        }
		
        //Function to show existing card deck.
        public void DisplayDeck()
        {
            foreach (var card in gameDeck)
            {
                Console.WriteLine($"{card.suit} {card.rank}");
            }
        }
		
        //Function to show player hands.
        public void DisplayHands()
        {
            foreach (var card in gameDeck)
            {
                Console.WriteLine($"Player {card.player} has {card.suit} {card.rank}");
            }
        }
    }
}
